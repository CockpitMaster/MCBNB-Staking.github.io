import React from 'react'

const Footer = () => {
  return (
    <div> hello i'm Footer</div>
  )
}

export default Footer;